
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import json

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

bot_state = {
    "running": False,
    "balance": 1000,
    "open_trades": 2,
    "pnl": "+4.5%"
}

@app.get("/api/status")
def get_status():
    return bot_state

@app.post("/api/start")
def start_bot():
    bot_state["running"] = True
    return {"message": "Bot started"}

@app.post("/api/stop")
def stop_bot():
    bot_state["running"] = False
    return {"message": "Bot stopped"}
