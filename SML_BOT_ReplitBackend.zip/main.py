
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

bot_status = {
    "running": False,
    "balance": 1000,
    "open_trades": 1,
    "pnl": "+2.5%"
}

@app.get("/api/status")
def get_status():
    return bot_status

@app.post("/api/start")
def start_bot():
    bot_status["running"] = True
    return {"message": "Bot started ✅"}

@app.post("/api/stop")
def stop_bot():
    bot_status["running"] = False
    return {"message": "Bot stopped ⛔"}
