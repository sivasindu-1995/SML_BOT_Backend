
# SML BOT Backend – Replit Version

## ✅ How to Use on Replit (Mobile Friendly)

1. Go to https://replit.com and log in
2. Create a new Python Repl
3. Upload all files from this folder (ZIP)
4. Install packages:
   `pip install fastapi uvicorn`
5. Run this command in Shell:
   `uvicorn main:app --host=0.0.0.0 --port=8000`
6. Click “Open in new tab” to get your API URL (copy for frontend)

That's your backend API for mobile dashboard!
